const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  age: { type: String, required: true },
  photo: { type: String }, // store image URL or path
});

module.exports = mongoose.model("User", userSchema);
