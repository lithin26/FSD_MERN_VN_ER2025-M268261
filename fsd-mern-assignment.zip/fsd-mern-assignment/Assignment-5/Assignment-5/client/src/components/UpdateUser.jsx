import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

function UpdateUser() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [age, setAge] = useState("");
  const [photo, setPhoto] = useState(null);       // New photo
  const [preview, setPreview] = useState(null);   // Preview for new photo
  const [currentPhoto, setCurrentPhoto] = useState(null); // Existing photo

  // Fetch existing user data
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get(`http://localhost:8000/get-users`);
        const user = res.data.allUsers.find(u => u._id === id);
        if (user) {
          setName(user.name);
          setEmail(user.email);
          setAge(user.age);
          setCurrentPhoto(user.photo);
          setPreview(user.photo); // show current photo as initial preview
        }
      } catch (err) {
        console.error(err);
        alert("Failed to fetch user data");
      }
    };
    fetchUser();
  }, [id]);

  // Handle new photo selection
  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        alert("Only image files are allowed");
        return;
      }
      setPhoto(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  // Submit updated data
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !age) {
      alert("Please fill all fields");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("name", name);
      formData.append("email", email);
      formData.append("age", age);
      if (photo) formData.append("photo", photo); // only send if new photo is selected

      await axios.put(`http://localhost:8000/update-user/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      alert("User updated successfully!");
      navigate("/"); // back to user list
    } catch (err) {
      console.error(err);
      alert("Failed to update user");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Update User</h2>
      <form onSubmit={handleSubmit} className="w-50 mx-auto">
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Age</label>
          <input
            type="text"
            className="form-control"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Photo</label>
          <input
            type="file"
            className="form-control"
            accept="image/*"
            onChange={handlePhotoChange}
          />
          {preview && (
            <img
              src={preview}
              alt="Preview"
              className="mt-3"
              style={{ width: "100%", maxHeight: "200px", objectFit: "cover" }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Update User
        </button>
      </form>
    </div>
  );
}

export default UpdateUser;
 