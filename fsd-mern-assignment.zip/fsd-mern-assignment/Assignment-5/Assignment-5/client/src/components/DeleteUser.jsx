import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function DeleteUser() {
  const [users, setUsers] = useState([]);

  // fetch all users
  const fetchUsers = async () => {
    const res = await axios.get("http://localhost:8000/users");
    setUsers(res.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // delete function
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8000/delete-user/${id}`);
      alert("User Deleted Successfully");
      fetchUsers(); // refresh list
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">User List</h2>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.age}</td>

              <td>
                <Link
                  to={`/update/${user.id}`}
                  className="btn btn-warning btn-sm me-2"
                >
                  Edit
                </Link>

                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleDelete(user.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DeleteUser;
