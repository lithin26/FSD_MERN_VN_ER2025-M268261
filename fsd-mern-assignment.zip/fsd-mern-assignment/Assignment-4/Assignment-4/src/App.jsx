import { useState } from "react";

import Quotes from "./components/Quotes";


function App() {
  return (
    <>
      {/* <MyComponent name="Niranjan" phNo="23456" /> */}
      {/* <ProfileCard name="Niranjan Sai" age="10" bio="learning React" />
      <ProfileCard name="Sai" age="13" bio="loves coding" />
      <ProfileCard name="John" age="9" bio="loves music" />
      <ProfileCard name="Alice" age="12" bio="Eat Sleep" />
      <Accordian/> */}
      {/* <Fruits/>
      <Students/> */}
      {/* <Cards/> */}
      {/* <NewCard/> */}
      {/* <Events/> */}
      {/* <Counter/> */}
      {/* <WordCounter/> */}
      {/* <ColorInput/> */}
      {/* <BgChange/> */}
      {/* <Dmode/> */}
      {/* <Dice/> */}
      <Quotes/>
      {/* <FetchData/> */}
      {/* <Home/>
      <About/>
      <Contact/> */}
      

    </>
  );
}

export default App;
