import React,{useEffect,useState} from 'react'
import axios from 'axios'

const Quotes = () => {
    const [quotes,SetQuotes]=useState([]);
    const fetchQuotes= async()=>{
        try{
            const response=await axios.get("https://dummyjson.com/quotes/random/10");
            SetQuotes(response.data);  
        }
        catch(error)
        {
            console.log(error);
            
        }
    }
    useEffect(()=>{
        fetchQuotes();
    },[])
    // console.log(quotes);
    
  return (
    <div className='con mt-3 mx-3'>
        {quotes.map((q,i)=>{
            return <div> <p className="fst-italic">{q.quote} <b>- {q.author}</b></p>
            <br/>
            
            </div>
                     

        })}
    </div>
  )
}

export default Quotes
