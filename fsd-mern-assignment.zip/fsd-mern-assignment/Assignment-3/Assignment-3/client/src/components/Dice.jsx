import React,{useState} from 'react'
import dice1 from '../assets/dice/dice1.png'
import dice2 from '../assets/dice/dice2.png'
import dice3 from '../assets/dice/dice3.png'
import dice4 from '../assets/dice/dice4.png'
import dice5 from '../assets/dice/dice5.png'
import dice6 from '../assets/dice/dice6.png'

const dice_image=[null,dice1,dice2,dice3,dice4,dice5,dice6]   //if images are in public folder then no need for array and import

const Dice = () => {
    const [dicep1,setDicep1]=useState("1")
    const [dicep2,setDicep2]=useState("1")
    const [win,setWin]=useState("🚩 Lets Play 🚩")
    function DiceRoll(){
        let a=Math.floor((Math.random()*6)+1);
        let b=Math.floor((Math.random()*6)+1);
        setDicep1(a);
        setDicep2(b);
        a>b ? setWin("🚩 Player 1 wins") 
       : b>a ? setWin("Player 2 wins 🚩") 
          : setWin("🚩 Tied 🚩");
    }
  return (
    <div className="lhead d-flex flex-column align-items-center justify-content-center gap-4" style={{minHeight:"100vh",maxWidth:"100%", backgroundColor:"black", color:"cyan"}}>
        <h1>{win}</h1>
        <div className='con d-flex justify-content-center gap-4'>
            <div className="con1" >
                <p style={{textAlign:"center"}}>Player 1</p>
                <img src={dice_image[dicep1]} alt="" />
            </div>
            <div>
                <p style={{textAlign:"center"}}>Player 2</p>
                <img src={dice_image[dicep2]} alt="" />
            </div>
            </div>
            <div>
               <div>
                <button className="btn btn-danger w-100" onClick={DiceRoll}>Roll</button>
               </div>
            </div>
           </div>
  )
}

export default Dice
